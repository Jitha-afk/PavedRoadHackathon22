﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;

namespace Microsoft.EDGS.WebAPISecurityCertified.Authentication
{
    public static class AuthExtension
    {
        private static Action<AuthenticationOptions> DefaultAuthenticationAction { get; } = delegate (AuthenticationOptions o)
        {
            o.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
        };

        public static AuthenticationBuilder AddAuthN(this IServiceCollection services, IConfiguration configuration, Action<AuthenticationOptions>? authAction = null)
        {
            var section = configuration.GetSection("AzureAd");

            var options = section.Get<AuthOptions>();

            if (options == null)
                throw new InvalidOperationException("Missing Authentication Configuration");

            if (!options.Type.Equals("JWT", StringComparison.OrdinalIgnoreCase))
                throw new NotImplementedException();

            void jwtOption(JwtBearerOptions jwt) => jwt.Bind(options);

            return services
                   .AddAuthentication(authAction ?? DefaultAuthenticationAction)
                   .AddJwtBearer(jwtOption);
        }


        public static void Bind(this JwtBearerOptions jwtOptions, AuthOptions authOptions)
        {
            if (authOptions == null)
                throw new ArgumentNullException(nameof(authOptions));

            jwtOptions.Authority = $"{authOptions.Instance}{authOptions.Domain}/v2.0";
            jwtOptions.TokenValidationParameters = new TokenValidationParameters
            {
                ValidIssuers = AuthOptions.GetAllowedIssuers(authOptions),
                ValidateIssuer = authOptions.ValidateIssuer.GetValueOrDefault(true),
                ValidateLifetime = authOptions.ValidateLifetime.GetValueOrDefault(true),
                ValidateAudience = true,
                RequireExpirationTime = true,
                RequireAudience = true,
                RequireSignedTokens = true
            };
            jwtOptions.Events = new JwtBearerEvents
            {
                OnTokenValidated = TokenValidated,
                OnAuthenticationFailed = AuthenticationFailed
            };
        }

        private static Task TokenValidated(TokenValidatedContext arg)
        {
            return Task.CompletedTask;
        }

        private static Task AuthenticationFailed(AuthenticationFailedContext arg)
        {
            return Task.CompletedTask;

        }
    }
}
