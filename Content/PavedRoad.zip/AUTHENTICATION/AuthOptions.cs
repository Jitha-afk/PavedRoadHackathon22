﻿namespace Microsoft.EDGS.WebAPISecurityCertified.Authentication
{
    public sealed class AuthOptions
    {
        public Uri Instance { get; set; } = new Uri("https://login.microsoft.com");

        public string Domain { get; set; } = "common";

        public string? TenantId { get; set; }

        public string? ClientId { get; set; }

        public string? CallbackPath { get; set; }

        public string? Scopes { get; set; }

        public bool? ValidateIssuer { get; set; } = true;

        public bool? ValidateLifetime { get; set; } = true;

        public string Type { get; set; } = "JWT";

        public IEnumerable<string>? ValidIssuers { get; set; }

        public bool IncludeMoreTenants { get; set; } = false; // For validation against multiple tenants override it in appsettings.

        public IEnumerable<string>? AdditionalTenants { get; set; }

        public IEnumerable<string> IssuerFormats { get; set; } = new string[]
        {
             "https://login.microsoftonline.com/{0}/"
        };

        public static IEnumerable<string> GetAllowedTenants(AuthOptions options)
        {
            var tenants = new List<string>();

            if (options.TenantId != null)
                tenants.Add(options.TenantId);


            if(options.IncludeMoreTenants && options.AdditionalTenants.Any())
                tenants.AddRange(options.AdditionalTenants);

            return tenants.Distinct();
        }


        public static IEnumerable<string> GetAllowedIssuers(AuthOptions options)
        {
            if (options.ValidIssuers != null && !options.ValidIssuers.Any())
                return options.ValidIssuers;

            var allowedTenants = GetAllowedTenants(options);

            //Add tenants to issuer format and returns the value
            return options
                .IssuerFormats
                .SelectMany(i => allowedTenants.Select(t => string.Format(i, t)))
                .ToArray();

        }
    }
}